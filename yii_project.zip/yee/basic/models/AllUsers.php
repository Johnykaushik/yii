<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "All_users".
 *
 * @property int $id
 * @property string $full_name
 * @property string $email
 * @property int $roll_no
 */
class AllUsers extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'All_users';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'full_name', 'email', 'roll_no'], 'required'],
            [['id', 'roll_no'], 'integer'],
            [['full_name', 'email'], 'string', 'max' => 40],
            [['id'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'full_name' => 'Full Name',
            'email' => 'Email',
            'roll_no' => 'Roll No',
        ];
    }
}

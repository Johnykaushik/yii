<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $fname
 * @property string $lname
 * @property string $email
 * @property string $password
 * @property string $image
 * @property string $date
 */
class Users extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
		//public $image;
    public static function tableName()
    {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['fname', 'lname', 'email', 'password'], 'required'],
            [['fname', 'lname'], 'string', 'max' => 30],
			[['image'],'file'],
			['email','email']
            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fname' => 'First name',
            'lname' => 'Last name',
            'email' => 'Email address',
            'password' => 'Password',
            'image' => 'Image',
            'date' => 'Date added',
        ];
    }
	
}

<?php

namespace app\controllers;

use Yii;
use app\models\Users;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;
use yii\helpers\Url;
/**
 * UsersController implements the CRUD actions for Users model.
 */
class UsersController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Users models.
     * @return mixed
     */
    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => Users::find(),
        ]);
        return $this->render('index', [
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Users model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    { 
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Users model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Users();
		
        if($model->load(Yii::$app->request->post()) && $model->validate()) {
			
			$image = UploadedFile::getInstance($model, 'image');
			$path = Yii::$app->basePath."/uploads/";
			$model->password = Yii::$app->getSecurity()->generatePasswordHash($model->password);
			$model->image=$image?$image->name:null;
			
			
			if($model->image){
				if(file_exists($path.$image->name)){
					$upload_img=time()."_".$model->image;
				}else {
					$upload_img=$model->image;
				}
				$image->saveAs($path.$upload_img);
			}
			if($model->save()){
				return $this->redirect(['view', 'id' => $model->id]);
			}else {
				Yii::$app->session->setFlash('error',"Unable to proceed required, please try later");
			}
        }
	
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Users model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
		
        $model = $this->findModel($id);
		
        if ($model->load(Yii::$app->request->post())) {
			$image = UploadedFile::getInstance($model, 'image');
			
			
			$path = Yii::$app->basePath."/uploads/";
			
			if($image && $image->name){
				if(file_exists($path.$image->name)){
					$upload_img=time()."_".$image->name;
				}else {
					$upload_img=$image->name;
				}
				$image->saveAs($path.$upload_img);
				$model->image=$upload_img;
				echo "new";
				var_dump($model->image);
			}elseif(!empty($model->current_image) && isset($model->current_image)) {
				$model->image=$model->current_image;
				echo "new";
			var_dump($model->image);
			}else {
				echo "image black";
			}
			echo "out";
			var_dump($model->image); die;
			if($model->save()){
				return $this->redirect(['view', 'id' => $model->id]);
			}else {
				Yii::$app->session->setFlash('error',"Unable to proceed required, please try later");
			}
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Users model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
		$data=$this->findModel($id);
		$img=Yii::$app->basePath."/uploads/".$data->image;
		if($data->image && file_exists($img)) {
			unlink($img);
		}
        if($data->delete()){
			Yii::$app->session->setFlash('success','Record successfully deleted');
		}else {
			Yii::$app->session->setFlash('error','unable to delete record');
		}
			return $this->redirect(['index']);
    }

    /**
     * Finds the Users model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Users the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Users::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}

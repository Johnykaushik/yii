<div class="jumbotron">
	<div class="btn-group-vertical">
		<button class="btn btn-primary">Primary</button>
		<button class="btn btn-success">Success</button>
		<button class="btn btn-danger">Danger</button>
	</div>
	
</div>

<?php	echo "<h3>".$message."</h3>"; 


?>
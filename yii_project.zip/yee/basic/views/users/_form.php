<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Users */
/* @var $form yii\widgets\ActiveForm */
?>
	<div class="col-sm-6" style="float:none;margin:auto;">
<div class="users-form">
    <?php $form = ActiveForm::begin(); ?>
    <?= $form->field($model, 'fname')->textInput(['maxlength' => true,'placeholder'=>"Enter first name"]) ?>

    <?= $form->field($model, 'lname')->textInput(['maxlength' => true,'placeholder'=>"Enter last name"]) ?>

    <?= $form->field($model, 'email')->input('email',['placeholder'=>"Enter email address"]) ?>
    <?= $model->isNewRecord ? $form->field($model, 'password')->passwordInput(['placeholder'=>"Enter password"]):null; ?>

    <?= $form->field($model,'image')->fileInput()->label("Upload an image"); ?>
	<?php 
		if($model->image) {
			echo $form->field($model,'current_image')->hiddenInput(['value'=>$model->image])->label('Current image');
			echo "<img src='http://localhost/yee/basic/uploads/$model->image' height=100 width=120>";
		}
	?>
	<div style='clear:both;'></div><br/>
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
</div>
